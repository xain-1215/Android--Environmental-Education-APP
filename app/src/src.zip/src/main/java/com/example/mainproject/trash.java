package com.example.mainproject;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class trash extends AppCompatActivity {

    private TextView scoreLabel;
    private TextView startLabel;
    private ImageView box;
    private ImageView trash;
    private TextView points;
    private TextView pointtitle;
    private RelativeLayout rulebg;
    private TextView ruleline;

    //Size
    private int frameWidth,frameHeight;
    private int boxSize;
    private int screenWidth;
    private int screenHeight;

    //Position
    private int boxX;
    private int trashX;
    private int trashY=-10;

    //Score
    public static int point4=0;
    private int times=0,addpoint=0;
    private double timess=0;

    //Initialize Class
    private Handler handler = new Handler();
    private Timer timer = new Timer();

    //Status Check
    private boolean action_flg = false;
    private boolean start_flg = false;
    private boolean check=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trash);
        startLabel = (TextView) findViewById(R.id.startLabel);
        trash = (ImageView) findViewById(R.id.trash);
        box = (ImageView) findViewById(R.id.box);
        final TextView ruletitle=findViewById(R.id.ruletitle4);
        final TextView rulecontent=findViewById(R.id.rulecontent4);
        ruleline=findViewById(R.id.line);
        pointtitle=findViewById(R.id.pointtitle);
        points=findViewById(R.id.point);
        rulebg= findViewById(R.id.rulebg);

        //Get screen size
        WindowManager wm = getWindowManager();
        Display disp = wm.getDefaultDisplay();
        Point size = new Point();
        disp.getSize(size);

        screenWidth = size.x;
        screenHeight = -(size.y);

        //Move to out of screen*or can set trash invisible*
        trash.setX(-150);
        trash.setY(-150);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(5 * 1000);//延遲5秒
                    ruleline.setVisibility(View.INVISIBLE);
                    rulecontent.setVisibility(rulecontent.INVISIBLE);
                    ruletitle.setVisibility(ruletitle.INVISIBLE);
                    rulebg.setVisibility(View.INVISIBLE);
                    check = true;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void changePos(){

        hitCheck();

        //Trash
        if(trashY==10){
            trashX=(int) Math.floor(Math.random() * (frameWidth-trash.getWidth()));
        }
        trashY += 12;
        if(trashY >frameHeight){
            trashX=(int) Math.floor(Math.random() * (frameWidth-trash.getWidth()));
            trashY =10;
        }
        trash.setX(trashX);
        trash.setY(trashY);

        //Move Box
        if(!action_flg){
            //Touching
            boxX += 30;

        } else {
            //Releasing
            boxX -= 30;
        }

        //Check box position
        if(boxX < 0) boxX = 0;
        //如果box超出邊界，做調整使其不超出邊界
        if(boxX > frameWidth - boxSize) boxX = frameWidth - boxSize;

        box.setX(boxX);

    }


    private void hitCheck(){

        //If the center of the ball is in the box, it counts as a hit
        int trashCenterX = trashX + trash.getWidth() / 2;
        int trashCenterY = trashY + trash.getHeight() / 2;

        //當trash的點和box點符合條件
        if((frameHeight-trashCenterY)<=1.5*boxSize &&boxX <= trashCenterX && trashCenterX <= boxX + boxSize)
        {
            point4 +=10;
            trashY = 10;
        }


    }

    public boolean onTouchEvent(MotionEvent me) {
        if (check == true) {

            if (start_flg == false) {

                start_flg = true;

                //Why get frame height and box height here?
                //Because the UI has not been set on the screen in onCreate()!!

                FrameLayout frame = (FrameLayout) findViewById(R.id.frame);
                frameWidth = frame.getWidth();
                frameHeight=frame.getHeight();
                boxX = (int) box.getX();

                //The box is a square.
                boxSize = box.getWidth();

                startLabel.setVisibility(View.GONE);
                box.setVisibility(box.VISIBLE);
                trash.setVisibility(trash.VISIBLE);
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                changePos();
                                if (point4 < 100) {
                                    timess++;
                                    if ((timess / 50) == (times + 1)) {
                                        times++;
                                    }
                                } else {
                                    runOnUiThread(new Runnable() {//跑主UI的thread
                                        @Override
                                        public void run() {
                                            rulebg.setVisibility(rulebg.VISIBLE);
                                            rulebg.setBackgroundResource(R.mipmap.rulebg);
                                            pointtitle.setVisibility(pointtitle.VISIBLE);
                                            points.setVisibility(points.VISIBLE);
                                            if (times <= 100) {
                                                point4=(100 - times) * 100 + 1000;
                                                points.setText(Integer.toString(addpoint));
                                                addpoint += 100;
                                                if (addpoint >= point4) {
                                                    points.setText(Integer.toString(point4));
                                                }
                                            } else {
                                                point4=1000;
                                                points.setText(Integer.toString(point4));
                                            }
                                                new Thread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        try{
                                                            Thread.sleep(5000);
                                                            finish();
                                                        }catch (InterruptedException e){
                                                            e.printStackTrace();
                                                        }
                                                    }
                                                }).start();
                                        }
                                    });

                                }
                            }
                        });
                    }
                }, 0, 20);
            } else {
                if (me.getAction() == MotionEvent.ACTION_DOWN) {
                    action_flg = true;
                } else if (me.getAction() == MotionEvent.ACTION_UP) {
                    action_flg = false;
                }
            }
        }
        return true;
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    //禁止返回鍵生效
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){
            if(getApplicationInfo().targetSdkVersion>= Build.VERSION_CODES.ECLAIR){
                event.startTracking();
            }
            else{
                onBackPressed();
            }
        }
        return false;
    }
    @Override
    public boolean onKeyUp(int keyCode,KeyEvent event){
        return super.onKeyUp(keyCode,event);
    }
}