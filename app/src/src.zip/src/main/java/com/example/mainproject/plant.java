package com.example.mainproject;

import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Timer;
import java.util.TimerTask;

public class plant extends AppCompatActivity {
    private int check=0,check2=0,check3=0,check4=0,check5=0,check6=0,check7=0;
    private int score;
    Timer timer;
    private int tt = 100 ;
    private int count=0,addpoint=0;
    private int im[] = {R.mipmap.tree,R.mipmap.stree,R.mipmap.btree};
    TextView scoreLabel;
    TextView t1;
    public static int point2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.plant);
        score = 2;
        //scoreLabel =findViewById(R.id.scoreLabel);
        final TextView ruletitle2=findViewById(R.id.ruletitle2);
        final TextView rulecontent2=findViewById(R.id.rulecontent2);
        final TextView ruleline=findViewById(R.id.line);
        final RelativeLayout rulebg=findViewById(R.id.rulebg);
        final TextView pointtitle=findViewById(R.id.pointtitle);
        final TextView points=findViewById(R.id.point);
        final ImageButton button=findViewById(R.id.imageButton);
        final ImageButton button2=findViewById(R.id.imageButton2);
        final ImageButton button3=findViewById(R.id.imageButton3);
        final ImageButton button4=findViewById(R.id.imageButton4);
        final ImageButton button5=findViewById(R.id.imageButton5);
        final ImageButton button6=findViewById(R.id.imageButton6);
        final ImageButton button7=findViewById(R.id.imageButton7);
        final ImageButton button11=findViewById(R.id.imageButton11);
        final ImageButton button21=findViewById(R.id.imageButton21);
        final ImageButton button31=findViewById(R.id.imageButton31);
        final ImageButton button41=findViewById(R.id.imageButton41);
        final ImageButton button51=findViewById(R.id.imageButton51);
        final ImageButton button61=findViewById(R.id.imageButton61);
        final ImageButton button71=findViewById(R.id.imageButton71);

        //scoreLabel.setText("Score: "+ score);
        //t1=findViewById(R.id.t1);
        timer = new Timer();
        final TimerTask task = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable(){
                    @Override
                    public void run() {
                        //t1.setText(tt + "second");
                        if(score!=100){
                            tt--;
                        }
                        else{
                            rulebg.setVisibility(rulebg.VISIBLE);
                            rulebg.setBackgroundResource(R.mipmap.rulebg);
                            pointtitle.setVisibility(pointtitle.VISIBLE);
                            points.setVisibility(points.VISIBLE);
                            point2=(score*10)+tt*100;
                            count++;
                            if(count==5){
                                finish();
                            }
                        }
                        if(tt<1) {
                            tt =100;
                        }
                        if(tt==90){
                            rulebg.setVisibility(rulebg.INVISIBLE);
                            ruleline.setVisibility(ruleline.INVISIBLE);
                            rulecontent2.setVisibility(rulecontent2.INVISIBLE);
                            ruletitle2.setVisibility(ruletitle2.INVISIBLE);
                            rulebg.setBackgroundResource(R.mipmap.bg2);
                            button.setVisibility(button.VISIBLE);
                            button2.setVisibility(button2.VISIBLE);
                            button3.setVisibility(button3.VISIBLE);
                            button4.setVisibility(button4.VISIBLE);
                            button5.setVisibility(button5.VISIBLE);
                            button6.setVisibility(button6.VISIBLE);
                            button7.setVisibility(button7.VISIBLE);
                        }

                    }
                });
            }
        };
        TimerTask add=new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (score ==100) {
                            points.setText(Integer.toString(addpoint));
                            addpoint += 100;
                            if (addpoint >= point2) {
                                points.setText(Integer.toString(point2));
                            }
                        }
                    }
                });
            }
        };
        timer.schedule(task,1000,1000);
        timer.schedule(add,0,20);
        if(score==100){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(5*1000);
                        finish();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
        tree(button,check,button11);
        tree(button2,check2,button21);
        tree(button3,check3,button31);
        tree(button4,check4,button41);
        tree(button5,check5,button51);
        tree(button6,check6,button61);
        tree(button7,check7,button71);
    }
    private void tree(final ImageButton buttons,int checks,final ImageButton buttons2){//切換土壤->樹苗->大樹的方法
        buttons.setOnClickListener(new Button.OnClickListener(){
            int checks=0;
            @Override
            public void onClick(View v){
                if(checks < 2){//確保點2次之後再點不會改變
                    if (checks == 0) {
                        buttons.setBackgroundResource(R.mipmap.stree);
                        checks++;
                    }
                    else {
                        buttons.setVisibility(View.INVISIBLE);
                        buttons2.setVisibility(View.VISIBLE);
                        checks++;
                    }
                    score = score + 7;
                    //scoreLabel.setText("Score: " + score);
                }
                //scoreLabel.setText("Score: "+ score);
            }
        }
        );
    }
    //禁止返回鍵生效
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){
            if(getApplicationInfo().targetSdkVersion>= Build.VERSION_CODES.ECLAIR){
                event.startTracking();
            }
            else{
                onBackPressed();
            }
        }
        return false;
    }
    @Override
    public boolean onKeyUp(int keyCode,KeyEvent event){
        return super.onKeyUp(keyCode,event);
    }
}

