package com.example.mainproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private int count=0;
    private int step=0;
    public static int stagestaus=0;
    private boolean sign=true;
    private boolean sign2=true;
    private int mark = 0;
    private int max=0;
    //private ImageView player;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ImageView player=findViewById(R.id.player);
        final ImageButton ducepoint=findViewById(R.id.duce);
        ducepoint.setOnClickListener(new Button.OnClickListener(){
                @Override
                public void onClick (View v){
                    if(sign==true) {
                        sign = false;
                        sign2=false;
                        step = (int) (Math.random() * 3) + 1;
                        final Timer timer=new Timer();
                             TimerTask ch = new TimerTask() {
                                @Override
                                public void run() {
                                    ducepoint.post(new Runnable() {
                                        @Override
                                        public void run() {
                                            switch (mark++) {
                                                case 0:
                                                    ducepoint.setBackgroundResource(R.drawable.duce1);
                                                    break;
                                                case 1:
                                                    ducepoint.setBackgroundResource(R.drawable.duce2);
                                                    break;
                                                case 2:
                                                    ducepoint.setBackgroundResource(R.mipmap.duce3);
                                                    break;
                                            }
                                            if (mark == 3 && max < 5) {
                                                mark = 0;
                                                max++;
                                            }
                                            if (max >= 5) {
                                                max = 0;
                                                if (step == 1) {
                                                    ducepoint.setBackgroundResource(R.drawable.duce1);
                                                } else if (step == 2) {
                                                    ducepoint.setBackgroundResource(R.drawable.duce2);
                                                } else if (step == 3) {
                                                    ducepoint.setBackgroundResource(R.mipmap.duce3);
                                                }
                                                timer.cancel();
                                            }
                                        }
                                    });
                                }
                            };
                        Timer timers=new Timer();
                        TimerTask move=new TimerTask() {
                            @Override
                            public void run() {
                                for (int i = 0; i < step; i++) {
                                    try {
                                        count++;
                                        stagestaus++;
                                        if (count == 1 || count == 2 || count == 3) {//依背景圖做調整
                                            player.layout(player.getLeft() + 210, player.getTop(), player.getRight() + 210, player.getBottom());
                                        } else if (count == 4 || count == 5 || count == 6 || count == 7) {
                                            player.layout(player.getLeft(), player.getTop() + 185, player.getRight(), player.getBottom() + 185);
                                        } else if (count == 8 || count == 9 || count == 10) {
                                            player.layout(player.getLeft() - 210, player.getTop(), player.getRight() - 210, player.getBottom());
                                        } else if (count == 11 || count == 12 || count == 13 || count == 14) {
                                            player.layout(player.getLeft(), player.getTop() - 185, player.getRight(), player.getBottom() - 185);
                                        }
                                        if (count == 3 || count == 6 || count == 9 || count == 12 || count == 14) {
                                            break;
                                        } else {
                                            Thread.sleep(650);
                                        }

                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                }
                                if (count == 1 || count == 2 || count == 4 || count == 5 || count == 7 || count == 8 || count == 10 || count == 11 || count == 13) {
                                    Intent it5 = new Intent(MainActivity.this, question.class);
                                    startActivity(it5);
                                } else if (count == 3) {
                                    Intent it2 = new Intent(MainActivity.this, activity2.class);
                                    Looper.prepare();
                                    ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation(MainActivity.this);
                                    startActivity(it2,options.toBundle());
                                    Looper.loop();
                                    //overridePendingTransition(R.transition.zoom_exit,R.transition.explode_anim);


                                } else if (count == 6) {
                                    Intent it1 = new Intent(MainActivity.this, plant.class);
                                    startActivity(it1);
                                } else if (count == 9) {
                                    Intent it3 = new Intent(MainActivity.this, shaket.class);
                                    startActivity(it3);
                                } else if (count == 12) {
                                    Intent it4 = new Intent(MainActivity.this, trash.class);
                                    startActivity(it4);
                                } else if (count == 14) {
                                    Intent it6 = new Intent(MainActivity.this, question.class);
                                    startActivity(it6);
                                    finish();
                                }
                                sign = true;
                            }
                        };
                        timer.schedule(ch,0, 100);
                        timers.schedule(move,3000);
                    }
            }
        });
    }
    //禁止返回鍵生效
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){
            if(getApplicationInfo().targetSdkVersion>= Build.VERSION_CODES.ECLAIR){
                event.startTracking();
            }
            else{
                onBackPressed();
            }
        }
        return false;
    }
    @Override
    public boolean onKeyUp(int keyCode,KeyEvent event){
        return super.onKeyUp(keyCode,event);
    }
}

