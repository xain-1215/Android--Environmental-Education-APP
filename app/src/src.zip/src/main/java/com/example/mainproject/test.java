package com.example.mainproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.net.HttpURLConnection;

public class test extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        Button get=findViewById(R.id.get);
        Button post=findViewById(R.id.post);
        TextView result=findViewById(R.id.textView6);

        get.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        /*try {
                            String uri = https://gdata.youtube.com/feeds/api/videos/mJsT0i95cAY?v=2&alt=jsonc;
                            HttpClient mHttpClient = new DefaultHttpClient();
                            HttpGet mHttpGet = new HttpGet(uri);
                            HttpResponse mHttpResponse = mHttpClient.execute(mHttpGet);
                            if (mHttpResponse.getStatusLine().getStatusCode() == HttpURLConnection.HTTP_OK) {
                                String mJsonText = EntityUtils.toString(mHttpResponse.getEntity());
                                String mTitle = new JSONObject(new JSONObject(mJsonText).getString("data")).getString("title");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }*/
                    }
                }).start();
            }
    });
    }
}
