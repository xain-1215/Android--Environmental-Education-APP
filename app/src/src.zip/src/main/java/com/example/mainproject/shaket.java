package com.example.mainproject;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.concurrent.locks.ReentrantLock;


public class shaket extends AppCompatActivity {

    //region variable field
    int[] imgId  = new int[10];
    ImageView imageView;
    Button button;
    TextView textView3;
    int p = 0;
    int sb = 0;
    int time = 30;
    String textTime;

    boolean quit = true;
    boolean shutDown = true;
    private SensorManager mSensorManager;   //體感(Sensor)使用管理
    private Sensor mSensor;                 //體感(Sensor)類別
    private float mLastX;                    //x軸體感(Sensor)偏移
    private float mLastY;                    //y軸體感(Sensor)偏移
    private float mLastZ;                    //z軸體感(Sensor)偏移
    private double mSpeed;                 //甩動力道數度
    private long mLastUpdateTime;           //觸發時間

    float x, y, z;
    float mDeltaX, mDeltaY, mDeltaZ;
    long mCurrentUpdateTime, mTimeInterval;
    public static int point3;

    //甩動力道數度設定值 (數值越大需甩動越大力，數值越小輕輕甩動即會觸發)
    private static final int SPEED_SHRESHOLD = 300;

    //觸發間隔時間
    private static final int UPTATE_INTERVAL_TIME = 100;
    static int timer_counter = 0;
    int DESIRED_TIME_WAITING = 3;
    //endregion
    RelativeLayout rulebg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shaket);
        final TextView ruletitle3=findViewById(R.id.ruletitle3);
        final TextView rulecontent3=findViewById(R.id.rulecontent3);
        final TextView ruleline=findViewById(R.id.line);
        rulebg=findViewById(R.id.rulebg);
        //取得體感(Sensor)服務使用權限
        mSensorManager = (SensorManager) this.getSystemService(Context.SENSOR_SERVICE);

        //取得手機Sensor狀態設定
        mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        //註冊體感(Sensor)甩動觸發Listener
        mSensorManager.registerListener(SensorListener, mSensor, SensorManager.SENSOR_DELAY_GAME);

        inits();

        final Thread myThread = new Thread(){
            @Override
            public void run(){
                while(shutDown) {
                    try {
                        Log.i("Sensor000", "Enter Thread ---------");
                        sleep(1400);
                        timer_counter = 3;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        final Thread timeThread = new Thread(){
            @Override
            public void run(){
                while(quit) {
                    try {
                        sleep(1000);
                        p = 3;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        button = findViewById(R.id.button);
        button.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                textView3.setVisibility(View.VISIBLE);
                imageView.setImageResource(imgId[0]);
                button.setVisibility(View.INVISIBLE);
                rulebg.setVisibility(rulebg.INVISIBLE);
                ruleline.setVisibility(ruleline.INVISIBLE);
                rulecontent3.setVisibility(rulecontent3.INVISIBLE);
                ruletitle3.setVisibility(ruletitle3.INVISIBLE);
                Log.i("Sensor00", "Button Activate");
                myThread.start();
                timeThread.start();
            }
        });
    }
    private final SensorEventListener SensorListener = new SensorEventListener() {
        public void onSensorChanged(SensorEvent mSensorEvent) {
            //當前觸發時間
            mCurrentUpdateTime = System.currentTimeMillis();

            //觸發間隔時間 = 當前觸發時間 - 上次觸發時間
            mTimeInterval = mCurrentUpdateTime - mLastUpdateTime;

            //若觸發間隔時間< 70 則return;
            if (mTimeInterval < UPTATE_INTERVAL_TIME) return;

            mLastUpdateTime = mCurrentUpdateTime;

            //取得xyz體感(Sensor)偏移
            x = mSensorEvent.values[0];
            y = mSensorEvent.values[1];
            z = mSensorEvent.values[2];

            //甩動偏移速度 = xyz體感(Sensor)偏移 - 上次xyz體感(Sensor)偏移
            mDeltaX = x - mLastX;
            mDeltaY = y - mLastY;
            mDeltaZ = z - mLastZ;

//            final ImageView imageView = (ImageView) findViewById(R.id.imageView);
            final TextView points=findViewById(R.id.point);
            final TextView pointtitle=findViewById(R.id.pointtitle);
            mLastX = x;
            mLastY = y;
            mLastZ = z;

            //體感(Sensor)甩動力道速度公式
            mSpeed = Math.sqrt(mDeltaX * mDeltaX + mDeltaY * mDeltaY + mDeltaZ * mDeltaZ) / mTimeInterval * 10000;

            //若體感(Sensor)甩動速度大於等於甩動設定值則進入 (達到甩動力道及速度)

            //達到搖一搖甩動後要做的事情
            if (p > 0) {
                if (time > 0) {
                    time = time - 1;
                    textTime = Integer.toString(time);
                    textView3.setText(textTime);
                    p = 0;
                } else {
                    quit = false;
                    shutDown = false;
                    DESIRED_TIME_WAITING = 4;
                    p = 0;
                    textView3.setVisibility(View.INVISIBLE);
                    imageView.setImageResource(imgId[9]);
                    button.setVisibility(View.VISIBLE);
                    button.setText(" 確定 ");
                    button.setOnClickListener(new Button.OnClickListener(){
                        @Override
                        public void onClick(View v) {
                            point();
                            imageView.setVisibility(View.VISIBLE);
                            rulebg.setVisibility(rulebg.VISIBLE);
                            rulebg.setBackgroundResource(R.mipmap.rulebg);
                            points.setVisibility(View.VISIBLE);
                            pointtitle.setVisibility(View.VISIBLE);
                            points.setText(Integer.toString(point3));
                            button.setVisibility(View.INVISIBLE);
                            th1.start();
                        }
                    });
                }
            }
            if (mSpeed >= SPEED_SHRESHOLD && timer_counter >= DESIRED_TIME_WAITING) {
                if (sb < 6) {
                    imageView.setImageResource(imgId[sb + 1]);
                    timer_counter = 0;
                    sb++;
                    if (sb == 6){
                        shutDown = false;
                        DESIRED_TIME_WAITING = 4;
                        quit = false;
                        textView3.setVisibility(View.INVISIBLE);
                        button.setVisibility(View.VISIBLE);
                        button.setText(" 確定 ");
                        button.setOnClickListener(new Button.OnClickListener(){
                            @Override
                            public void onClick(View v) {
                                point();
                                imageView.setVisibility(View.VISIBLE);
                                points.setVisibility(View.VISIBLE);
                                rulebg.setVisibility(rulebg.VISIBLE);
                                rulebg.setBackgroundResource(R.mipmap.rulebg);
                                pointtitle.setVisibility(View.VISIBLE);
                                points.setText(Integer.toString(point3));
                                button.setVisibility(View.INVISIBLE);
                                th1.start();
                            }
                        });
                    }
                }
            }
        }
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };
    private void inits(){
        button =findViewById(R.id.button);
        textView3 =findViewById(R.id.textView3);
        //textView2.setVisibility(View.INVISIBLE);
        //textView.setVisibility(View.INVISIBLE);
        int [] res_arr = {R.mipmap.img00, R.mipmap.img01, R.mipmap.img02, R.mipmap.img03, R.mipmap.img04, R.mipmap.img05, R.mipmap.img06, R.mipmap.img07, R.mipmap.img08, R.mipmap.img09};
        imgId = res_arr;
        imageView = findViewById(R.id.imgView);
        //imageView.setImageResource(imgId[7]);
    }

    private void point(){
        if (time >= 20){
            point3=10000;
        }else if (time >= 16) {
            point3=8000;
        }else if (time >= 12) {
            point3=6000;
        }else if (time >= 8) {
            point3=4000;
        }else if (time >= 4) {
            point3=2000;
        }else{
            point3=0;
        }
    }
    Thread th1=new Thread(new Runnable() {
        @Override
        public void run() {
            try{
                th1.sleep(5000);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
            finish();
        }
    });

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //在程式關閉時移除體感(Sensor)觸發
        mSensorManager.unregisterListener(SensorListener);
    }
    //禁止返回鍵生效
    /*public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){
            if(getApplicationInfo().targetSdkVersion>= Build.VERSION_CODES.ECLAIR){
                event.startTracking();
            }
            else{
                onBackPressed();
            }
        }
        return false;
    }
    @Override
    public boolean onKeyUp(int keyCode,KeyEvent event){
        return super.onKeyUp(keyCode,event);
    }*/
}

