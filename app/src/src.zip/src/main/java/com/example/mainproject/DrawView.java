package com.example.mainproject;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;


public class DrawView extends View {


    public DrawView(Context context) {
        super(context);
    }

    public DrawView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public DrawView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public DrawView(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // 建立畫筆
        Paint p = new Paint();
        p.setColor(Color.RED);// 設定紅色
        p.setStyle(Paint.Style.FILL);//設定填滿
        //canvas.drawRect(60, 60, 80, 80, p);// 正方形
        //canvas.drawRect(580,940, 630, 1150, p);// 長方形
        //canvas.drawRect(1020,370, 1070, 1150, p);// 長方形
        //canvas.drawRect(750,370, 1070, 420, p);// 長方形
        //canvas.drawRect(170,940, 580, 990, p);// 長方形
        //canvas.drawRect(170,200, 220, 940, p);// 長方形
        //canvas.drawRect(750,200, 800, 370, p);// 長方形
        p.setColor(Color.YELLOW);//
        canvas.drawRect(150,180, 800, 200, p);// 長方形
        //canvas.drawRect(bike.getLeft(),bike.getTop()+500,0,0,p);

    }

}

