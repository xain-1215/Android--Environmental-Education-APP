package com.example.mainproject;

import android.os.Build;
import android.os.Bundle;
import android.transition.Explode;
import android.transition.Fade;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Time;
import java.util.Timer;
import java.util.TimerTask;

public class activity2 extends AppCompatActivity {
    private int dx=0,dy=0;//腳踏車移動的x,y軸單位
    Timer timer;//宣告時間函式
    private int times=0,addpoint=0;//秒數
    public static int point;//此遊戲的得分

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        /*getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        getWindow().setEnterTransition(new Explode());
        getWindow().setExitTransition(new Explode());*/
        getWindow().setEnterTransition(new Fade().setDuration(2000));
        setContentView(R.layout.activity_main2);
        final Button button1 = findViewById(R.id.button1);
        final Button button2=findViewById(R.id.button2);
        final Button button3=findViewById(R.id.button3);
        final ImageView bike=(ImageView) findViewById(R.id.bike);
        final TextView counter=findViewById(R.id.textView);
        final TextView ruletitle=findViewById(R.id.ruletitle);
        final TextView rulecontent=findViewById(R.id.rulecontent);
        final TextView ruleline=findViewById(R.id.line);
        final RelativeLayout rulebg=findViewById(R.id.rulebg);
        final TextView pointtitle=findViewById(R.id.pointtitle);
        final TextView points=findViewById(R.id.point);

        //com.example.mainproject.DrawView drawView=findViewById(R.id.view);
        timer=new Timer();//時間函式初始化

        button1.setOnClickListener(new Button.OnClickListener(){
            //要設定監聽器材可以用onclick(點擊的功能)
            @Override
            public void onClick(View v) {
                dx--;//dx是自設定用來控制左右以及判別的
                if(dx<=1&&dx>=(-1)&&dy<=8) {//這邊是以圖形為準的邊界*之後可將牆壁一起作為背景圖片 再行調整*
                    bike.layout(bike.getLeft() - 45, bike.getTop(), bike.getRight()-45, bike.getBottom());//這邊重新設定了bike的位置->在新的地方出現
                    //*之後可以增加它移動的動畫*
                }
                else if((-13)<=dx&& dx<=1 && dy==8){
                    bike.layout(bike.getLeft() - 45, bike.getTop(), bike.getRight()-45, bike.getBottom());
                }
                else if((-13)<=dx&&dx<=(-11)&&dy>=8&&dy<=15){
                    bike.layout(bike.getLeft() - 45, bike.getTop(), bike.getRight()-45, bike.getBottom());
                }
                else if((-13)<=dx&&dx<=(-1)&&dy==15){
                    bike.layout(bike.getLeft() - 45, bike.getTop(), bike.getRight()-45, bike.getBottom());
                }
                else if((-4)<=dx&&dx<=-1&&dy>=15&&dy<=20){
                    bike.layout(bike.getLeft() - 45, bike.getTop(), bike.getRight()-45, bike.getBottom());
                }
                else{
                    if(dy>=20){
                        tips2();
                    }
                    else {
                        tips();
                        dx++;
                    }
                }
            }
        });


        button2.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v){
                dx++;
                if(dx<=1&&dx>=(-1)&&dy<=8){
                    bike.layout(bike.getLeft()+45, bike.getTop(), bike.getRight()+45, bike.getBottom());

                }
                else if((-13)<=dx&& dx<=1 && dy==8){
                    bike.layout(bike.getLeft()+45, bike.getTop(), bike.getRight()+45, bike.getBottom());

                }
                else if((-13)<=dx&&dx<=(-11)&&dy>=8&&dy<=15){
                    bike.layout(bike.getLeft()+45, bike.getTop(), bike.getRight()+45, bike.getBottom());

                }
                else if((-13)<=dx&&dx<=(-1)&&dy==15){
                    bike.layout(bike.getLeft()+45, bike.getTop(), bike.getRight()+45, bike.getBottom());

                }
                else if((-4)<=dx&&dx<=-1&&dy>=15&&dy<=20){
                    bike.layout(bike.getLeft()+45, bike.getTop(), bike.getRight()+45, bike.getBottom());

                }
                else{
                    if(dy>=20){
                        tips2();
                    }
                    else {
                        tips();
                        dx --;
                    }
                }

            }
        });
        button3.setOnClickListener(new Button.OnClickListener(){//up
            @Override
            public void onClick(View v){
                dy++;
                if(dx<=1&&dx>=(-1)&&dy<=8){
                    bike.layout(bike.getLeft(), bike.getTop()-40, bike.getRight(), bike.getBottom()-40);
                }
                else if((-13)<=dx&&dx<=(-11)&&dy<=15&&dy>=8){
                    bike.layout(bike.getLeft(), bike.getTop()-42, bike.getRight(), bike.getBottom()-42);

                }
                else if((-4)<=dx&&dx<-1&&dy<=20&&dy>=15){
                    bike.layout(bike.getLeft(), bike.getTop()-50, bike.getRight(), bike.getBottom()-50);

                }
                else{
                    if(dy>=20){
                        tips2();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Thread.sleep(5*1000);//延遲5秒後關閉此頁面
                                    finish();
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                //onDestroy();
                            }
                        }).start();

                    }
                    else {
                        tips();
                        dy--;
                    }
                }
            }
        });
        //開始跑時間執行緒
        final TimerTask task=new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {//跑主UI的thread
                    @Override
                    public void run() {
                        if (dy >20) {//遊戲結束的條件:*因為最後一定是按了"上"才到達終點*
                            point =11000- (times * 100);//分數的計算方式(*因為前面規則在跑時有10秒過去了，所以在得分上+回去)，預設滿分10000分
                            if(point<0){
                                point=0;
                            }
                            rulebg.setVisibility(rulebg.VISIBLE);
                            rulebg.setBackgroundResource(R.mipmap.rulebg);
                            pointtitle.setVisibility(pointtitle.VISIBLE);
                            points.setVisibility(points.VISIBLE);
                            rulecontent.setVisibility(rulecontent.VISIBLE);
                            rulecontent.setText("");
                            button1.setVisibility(button1.INVISIBLE);
                            button2.setVisibility(button2.INVISIBLE);
                            button3.setVisibility(button3.INVISIBLE);
                            bike.setVisibility(bike.INVISIBLE);
                        }
                        else {
                            times++;
                        }
                        if (times == 10) {//過10S之後自動進入遊戲
                            rulebg.setVisibility(rulebg.INVISIBLE);
                            ruleline.setVisibility(ruleline.INVISIBLE);
                            rulecontent.setVisibility(rulecontent.INVISIBLE);
                            ruletitle.setVisibility(ruletitle.INVISIBLE);
                            bike.setVisibility(bike.VISIBLE);//*是因為佈局rulebg不能擋掉這些，所以一開始只好先設定成invisible*
                            button1.setVisibility(button1.VISIBLE);//也可以調整佈局
                            button2.setVisibility(button2.VISIBLE);
                            button3.setVisibility(button3.VISIBLE);//*設定成visible or gone的只能在UIThread*
                            //init();
                        }
                        counter.setText(Integer.toString(times - 10));//要扣掉前面顯示規則時跑的時間
                    }
                });
            }
        };
        TimerTask add=new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (dy >20) {
                            points.setText(Integer.toString(addpoint));
                            addpoint += 100;
                            if (addpoint >= point) {
                                points.setText(Integer.toString(point));
                            }
                        }
                    }
                });
            }
        };
        timer.schedule(task,1000,1000);//時間在經過幾豪秒之後開始以1000毫秒執行
        timer.schedule(add,0,20);

    }
    /*private void init() {//這邊利用drawview在螢幕上畫出東西來(依螢幕比例)，是用來當作終點線
        RelativeLayout layout=(RelativeLayout)findViewById(R.id.my);
        final com.example.mainproject.DrawView view=new com.example.mainproject.DrawView(this);
        view.setMinimumHeight(500);
        view.setMinimumWidth(300);
        //通知view元件重繪
        view.invalidate();
        layout.addView(view);

    }*/
    private void tips(){//浮動式訊息
        Toast toast = Toast.makeText(activity2.this, R.string.test, Toast.LENGTH_SHORT);
        toast.show();
    }
    private void tips2(){//浮動式訊息(遊戲結束的)
        Toast toast = Toast.makeText(activity2.this, R.string.end, Toast.LENGTH_SHORT);
        toast.show();
    }
    /*@Override
    protected void onDestroy() {
        super.onDestroy();
    }*/
    //禁止返回鍵生效
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){
            if(getApplicationInfo().targetSdkVersion>= Build.VERSION_CODES.ECLAIR){
                event.startTracking();
            }
            else{
                onBackPressed();
            }
        }
        return false;
    }
    @Override
    public boolean onKeyUp(int keyCode,KeyEvent event){
        return super.onKeyUp(keyCode,event);
    }
}
