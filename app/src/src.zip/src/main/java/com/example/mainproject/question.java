package com.example.mainproject;

import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class question extends AppCompatActivity {
    public static int pointq;
    private int addpoint=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question);
        final TextView question=findViewById(R.id.qustion);
        final TextView result=findViewById(R.id.qustion);
        final Button ans1=findViewById(R.id.answer1);
        final Button ans2=findViewById(R.id.answer2);
        final Button ans3=findViewById(R.id.answer3);
        final Button ans4=findViewById(R.id.answer4);
        final TextView pointtitle=findViewById(R.id.pointtitle);
        final TextView points=findViewById(R.id.point4);
        final TextView ruleline=findViewById(R.id.line);
        final Button finish=findViewById(R.id.button);
        final Timer timer=new Timer();
        final TimerTask add=new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(MainActivity.stagestaus==14){
                            points.setText(Integer.toString(addpoint));
                            addpoint += 100;
                            if (addpoint >= pointq) {
                                points.setText(Integer.toString(pointq));
                            }
                        }
                    }
                });
            }
        };
        if(MainActivity.stagestaus==14){
            runOnUiThread(new Runnable() {//跑主UI的thread
                @Override
                public void run() {
                    RelativeLayout rulebg=findViewById(R.id.rulebg);
                    rulebg.setBackgroundResource(R.mipmap.rulebg);
                    ans1.setVisibility(View.INVISIBLE);
                    ans2.setVisibility(View.INVISIBLE);
                    ans3.setVisibility(View.INVISIBLE);
                    ans4.setVisibility(View.INVISIBLE);
                    points.setVisibility(View.VISIBLE);
                    pointtitle.setVisibility(View.VISIBLE);
                    //ruleline.setVisibility(View.VISIBLE);
                    question.setVisibility(View.INVISIBLE);
                    pointq = pointq + activity2.point + plant.point2 + shaket.point3 + trash.point4;
                    timer.schedule(add,0,20);
                    finish.setVisibility(View.VISIBLE);
                }
            });
        }
        if(MainActivity.stagestaus==1){
            question.setText(R.string.q1);
            ans1.setText(R.string.a1);
            ans2.setText(R.string.a2);
            ans3.setText(R.string.a3);
            ans4.setText(R.string.a4);
        }
        else if(MainActivity.stagestaus==2){
            question.setText(R.string.q2);
            ans1.setText(R.string.a21);
            ans2.setText(R.string.a22);
            ans3.setText(R.string.a23);
            ans4.setText(R.string.a24);
        }
        else if(MainActivity.stagestaus==4){
            question.setText(R.string.q3);
            ans1.setText(R.string.a31);
            ans2.setText(R.string.a32);
            ans3.setText(R.string.a33);
            ans4.setText(R.string.a34);
        }
        else if(MainActivity.stagestaus==5){
            question.setText(R.string.q4);
            ans1.setText(R.string.a41);
            ans2.setText(R.string.a42);
            ans3.setText(R.string.a43);
            ans4.setText(R.string.a44);
        }
        else if(MainActivity.stagestaus==7){
            question.setText(R.string.q5);
            ans1.setText(R.string.a51);
            ans2.setText(R.string.a52);
            ans3.setText(R.string.a53);
            ans4.setText(R.string.a54);
        }
        else if(MainActivity.stagestaus==8){
            question.setText(R.string.q6);
            ans1.setText(R.string.a61);
            ans2.setText(R.string.a62);
            ans3.setText(R.string.a63);
            ans4.setText(R.string.a64);
        }else if(MainActivity.stagestaus==10){
            question.setText(R.string.q7);
            ans1.setText(R.string.a71);
            ans2.setText(R.string.a72);
            ans3.setText(R.string.a73);
            ans4.setText(R.string.a74);
        }else if(MainActivity.stagestaus==11){
            question.setText(R.string.q8);
            ans1.setText(R.string.a81);
            ans2.setText(R.string.a82);
            ans3.setText(R.string.a83);
            ans4.setText(R.string.a84);
        }
        else if(MainActivity.stagestaus==13){
            question.setText(R.string.q9);
            ans1.setText(R.string.a91);
            ans2.setText(R.string.a92);
            ans3.setText(R.string.a93);
            ans4.setText(R.string.a94);
        }
        ans1.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                /*ans1.setEnabled(false);
                ans2.setEnabled(false);
                ans3.setEnabled(false);
                ans4.setEnabled(false);*/
                runOnUiThread(new Runnable() {//跑主UI的thread
                    @Override
                    public void run() {
                        result.setVisibility(View.VISIBLE);
                        ans1.setVisibility(View.INVISIBLE);
                        ans2.setVisibility(View.INVISIBLE);
                        ans3.setVisibility(View.INVISIBLE);
                        ans4.setVisibility(View.INVISIBLE);
                            if (MainActivity.stagestaus == 1) {
                                result.setText(R.string.no);
                            } else if (MainActivity.stagestaus == 2) {
                                result.setText(R.string.yes);
                                pointq += 1000;
                            } else if (MainActivity.stagestaus == 4) {
                                result.setText(R.string.no);
                            } else if (MainActivity.stagestaus == 5) {
                                result.setText(R.string.no);
                            } else if (MainActivity.stagestaus == 7) {
                                result.setText(R.string.no);
                            } else if (MainActivity.stagestaus == 8) {
                                result.setText(R.string.yes);
                                pointq += 1000;
                            } else if (MainActivity.stagestaus == 10) {
                                result.setText(R.string.no);
                            } else if (MainActivity.stagestaus == 11) {
                                result.setText(R.string.yes);
                                pointq += 1000;
                            } else if (MainActivity.stagestaus == 13) {
                                result.setText(R.string.no);
                            }
                        th1.start();
                    }
                });
            }
        });
        ans2.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                /*ans1.setEnabled(false);
                ans2.setEnabled(false);
                ans3.setEnabled(false);
                ans4.setEnabled(false);*/
                runOnUiThread(new Runnable() {//跑主UI的thread
                    @Override
                    public void run() {
                        result.setVisibility(View.VISIBLE);
                        ans1.setVisibility(View.INVISIBLE);
                        ans2.setVisibility(View.INVISIBLE);
                        ans3.setVisibility(View.INVISIBLE);
                        ans4.setVisibility(View.INVISIBLE);
                            if (MainActivity.stagestaus == 1) {
                                result.setText(R.string.no);
                            } else if (MainActivity.stagestaus == 2) {
                                result.setText(R.string.no);
                            } else if (MainActivity.stagestaus == 4) {
                                result.setText(R.string.no );
                            } else if (MainActivity.stagestaus == 5) {
                                result.setText(R.string.yes);
                                pointq += 1000;
                            } else if (MainActivity.stagestaus == 7) {
                                result.setText(R.string.no );
                            } else if (MainActivity.stagestaus == 8) {
                                result.setText(R.string.no );
                            } else if (MainActivity.stagestaus == 10) {
                                result.setText(R.string.no );
                            } else if (MainActivity.stagestaus == 11) {
                                result.setText(R.string.no );
                            } else if (MainActivity.stagestaus == 13) {
                                result.setText(R.string.no );
                            }
                        th1.start();
                        }
                });
            }
        });
        ans3.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                /*ans1.setEnabled(false);
                ans2.setEnabled(false);
                ans3.setEnabled(false);
                ans4.setEnabled(false);*/
                runOnUiThread(new Runnable() {//跑主UI的thread
                    @Override
                    public void run() {
                        result.setVisibility(View.VISIBLE);
                        ans1.setVisibility(View.INVISIBLE);
                        ans2.setVisibility(View.INVISIBLE);
                        ans3.setVisibility(View.INVISIBLE);
                        ans4.setVisibility(View.INVISIBLE);
                if(MainActivity.stagestaus==1){
                    result.setText(R.string.no);
                }
                else if(MainActivity.stagestaus==2){
                    result.setText(R.string.no);
                }
                else if(MainActivity.stagestaus==4){
                    result.setText(R.string.no );
                }
                else if(MainActivity.stagestaus==5){
                    result.setText(R.string.no );
                }
                else if(MainActivity.stagestaus==7){
                    result.setText(R.string.no );
                }
                else if(MainActivity.stagestaus==8){
                    result.setText(R.string.no );
                }else if(MainActivity.stagestaus==10){
                    result.setText(R.string.yes);
                    pointq+=1000;
                }else if(MainActivity.stagestaus==11){
                    result.setText(R.string.no );
                }
                else if(MainActivity.stagestaus==13){
                    result.setText(R.string.yes);
                    pointq+=1000;
                }
                        th1.start();
                    }
                });
            }
        });
        ans4.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                /*ans1.setEnabled(false);
                ans2.setEnabled(false);
                ans3.setEnabled(false);
                ans4.setEnabled(false);*/
                runOnUiThread(new Runnable() {//跑主UI的thread
                    @Override
                    public void run() {
                        result.setVisibility(View.VISIBLE);
                        ans1.setVisibility(View.INVISIBLE);
                        ans2.setVisibility(View.INVISIBLE);
                        ans3.setVisibility(View.INVISIBLE);
                        ans4.setVisibility(View.INVISIBLE);
                if(MainActivity.stagestaus==1){
                    result.setText(R.string.yes);
                    pointq+=1000;
                }
                else if(MainActivity.stagestaus==2){
                    result.setText(R.string.no );
                }
                else if(MainActivity.stagestaus==4){
                    result.setText(R.string.yes);
                    pointq+=1000;
                }
                else if(MainActivity.stagestaus==5){
                    result.setText(R.string.no );
                }
                else if(MainActivity.stagestaus==7){
                    result.setText(R.string.yes);
                    pointq+=1000;
                }
                else if(MainActivity.stagestaus==8){
                    result.setText(R.string.yes);
                    pointq+=1000;
                }else if(MainActivity.stagestaus==10){
                    result.setText(R.string.no );
                }else if(MainActivity.stagestaus==11){
                    result.setText(R.string.yes);
                    pointq+=1000;
                }
                else if(MainActivity.stagestaus==13){
                    result.setText(R.string.no );
                }
                            th1.start();
                    }
                });
            }
        });
        finish.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    Thread th1=new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                th1.sleep(5000);
            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
            finish();
        }
    });
    //禁止返回鍵生效
    /*public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK){
            if(getApplicationInfo().targetSdkVersion>= Build.VERSION_CODES.ECLAIR){
                event.startTracking();
            }
            else{
                onBackPressed();
            }
        }
        return false;
    }
    @Override
    public boolean onKeyUp(int keyCode,KeyEvent event){
        return super.onKeyUp(keyCode,event);
    }*/
}
